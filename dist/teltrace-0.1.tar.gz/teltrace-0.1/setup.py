from setuptools import setup, find_packages

setup(
     name='teltrace',
     version='0.1',
     packages=find_packages()

 )